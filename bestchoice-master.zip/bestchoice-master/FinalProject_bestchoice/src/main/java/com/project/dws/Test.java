package com.project.dws;

public class Test {

	public static void main(String[] args) {
		System.out.println("확인용입니다");
	}

}
